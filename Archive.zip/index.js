// index.js
import './src/server.js';